package com.myapplock.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

object UI {
    val BG1 = 0xFF0F172A.toInt()
    val BG2 = 0xFF3B1D6E.toInt()
    val ACCENT = 0xFF22D3EE.toInt()
    val CARD = 0x22FFFFFF
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun gradient(): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(BG1, BG2))

    fun round(c: Context, color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(c, r).toFloat()
        return g
    }

    fun text(c: Context, s: CharSequence, size: Float = 16f, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        t.setTextColor(color)
        t.gravity = Gravity.CENTER
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    fun button(c: Context, s: CharSequence, onClick: () -> Unit): TextView {
        val t = text(c, s, 16f, BG1, true)
        t.background = round(c, ACCENT, 28)
        t.setPadding(dp(c, 28), dp(c, 14), dp(c, 28), dp(c, 14))
        t.setOnClickListener { onClick() }
        return t
    }

    fun ghost(c: Context, s: CharSequence, onClick: () -> Unit): TextView {
        val t = text(c, s, 15f, ACCENT, false)
        t.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10))
        t.setOnClickListener { onClick() }
        return t
    }

    fun edit(c: Context, hint: String): EditText {
        val e = EditText(c)
        e.hint = hint
        e.setHintTextColor(0x88FFFFFF.toInt())
        e.setTextColor(Color.WHITE)
        e.background = round(c, CARD, 14)
        e.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12))
        e.inputType = InputType.TYPE_CLASS_TEXT
        e.setSingleLine(true)
        return e
    }

    fun params(c: Context, w: Int, h: Int, top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.topMargin = dp(c, top)
        return p
    }

    fun column(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER
        l.setPadding(dp(c, 24), dp(c, 40), dp(c, 24), dp(c, 24))
        return l
    }

    fun show(root: FrameLayout, col: LinearLayout) {
        root.removeAllViews()
        val sv = ScrollView(root.context)
        sv.isFillViewport = true
        sv.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(sv)
    }
}
