package com.myapplock.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LockActivity : AppCompatActivity() {
    private var target = ""
    private lateinit var root: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        target = intent.getStringExtra("pkg") ?: ""
        root = FrameLayout(this)
        root.background = UI.gradient()
        setContentView(root)
        showLock()
    }

    private fun appLabel(): String {
        if (target.isEmpty()) return getString(R.string.app_name)
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(target, 0)).toString()
        } catch (e: Exception) {
            target
        }
    }

    private fun showLock() {
        val col = UI.column(this)
        col.addView(UI.text(this, "🔒", 44f))
        col.addView(UI.text(this, appLabel(), 22f, Color.WHITE, true),
            UI.params(this, UI.WRAP, UI.WRAP, 8))
        val isPin = Prefs.type == "pin"
        val msg = UI.text(this, getString(if (isPin) R.string.enter_pin else R.string.draw_pattern),
            15f, 0xCCFFFFFF.toInt())
        col.addView(msg, UI.params(this, UI.WRAP, UI.WRAP, 6))

        val onEntry: (String) -> Boolean = { v ->
            if (Prefs.checkCred(v)) {
                unlocked()
                true
            } else {
                msg.text = getString(if (isPin) R.string.wrong_pin else R.string.wrong_pattern)
                msg.setTextColor(0xFFFF6B6B.toInt())
                false
            }
        }

        if (isPin) {
            col.addView(PinPadView(this, onEntry), UI.params(this, UI.WRAP, UI.WRAP, 16))
        } else {
            val size = minOf(resources.displayMetrics.widthPixels - UI.dp(this, 64), UI.dp(this, 320))
            col.addView(PatternView(this, onEntry), UI.params(this, size, size, 16))
        }
        col.addView(UI.ghost(this, getString(R.string.forgot)) { showForgot() },
            UI.params(this, UI.WRAP, UI.WRAP, 16))
        UI.show(root, col)
    }

    private fun showForgot() {
        val col = UI.column(this)
        col.addView(UI.text(this, getString(R.string.forgot_title), 22f, Color.WHITE, true))
        val qs = resources.getStringArray(R.array.questions)
        col.addView(UI.text(this, qs[Prefs.qIdx.coerceIn(0, qs.size - 1)], 16f),
            UI.params(this, UI.WRAP, UI.WRAP, 20))
        val ans = UI.edit(this, getString(R.string.answer_hint))
        col.addView(ans, UI.params(this, UI.MATCH, UI.WRAP, 10))
        col.addView(UI.button(this, getString(R.string.verify)) {
            if (Prefs.checkAnswer(ans.text.toString())) recovered() else bad()
        }, UI.params(this, UI.MATCH, UI.WRAP, 14))
        col.addView(UI.text(this, getString(R.string.or_code), 14f, 0xAAFFFFFF.toInt()),
            UI.params(this, UI.WRAP, UI.WRAP, 24))
        val code = UI.edit(this, "XXXX-XXXX-XXXX")
        code.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        col.addView(code, UI.params(this, UI.MATCH, UI.WRAP, 10))
        col.addView(UI.button(this, getString(R.string.verify)) {
            if (Prefs.checkCode(code.text.toString())) recovered() else bad()
        }, UI.params(this, UI.MATCH, UI.WRAP, 14))
        col.addView(UI.ghost(this, "←") { showLock() }, UI.params(this, UI.WRAP, UI.WRAP, 14))
        UI.show(root, col)
    }

    private fun bad() {
        Toast.makeText(this, R.string.wrong_recovery, Toast.LENGTH_SHORT).show()
    }

    private fun recovered() {
        startActivity(Intent(this, SetupActivity::class.java).putExtra("reset", true))
        finish()
    }

    private fun unlocked() {
        if (target.isEmpty()) AppLockState.selfUnlocked = true else AppLockState.unlocked = target
        finish()
        overridePendingTransition(0, 0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (target.isEmpty()) {
            finishAffinity()
        } else {
            val h = Intent(Intent.ACTION_MAIN)
            h.addCategory(Intent.CATEGORY_HOME)
            h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(h)
            finish()
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isFinishing) finish()
    }
}
