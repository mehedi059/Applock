package com.myapplock.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/** Steps: 0 language, 1 lock type, 2 create credential, 3 security question, 4 recovery code. */
class SetupActivity : AppCompatActivity() {
    private var reset = false
    private var step = 0
    private var type = "pin"
    private var first: String? = null
    private var qIdx = 0
    private var code = ""
    private lateinit var root: FrameLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        reset = intent.getBooleanExtra("reset", false)
        step = b?.getInt("step") ?: (if (reset) 1 else 0)
        type = b?.getString("type") ?: "pin"
        root = FrameLayout(this)
        root.background = UI.gradient()
        setContentView(root)
        render()
    }

    override fun onSaveInstanceState(o: Bundle) {
        super.onSaveInstanceState(o)
        o.putInt("step", step)
        o.putString("type", type)
    }

    private fun render() {
        when (step) {
            0 -> stepLang()
            1 -> stepType()
            2 -> stepCred()
            3 -> stepQa()
            else -> stepCode()
        }
    }

    private fun stepLang() {
        val col = UI.column(this)
        col.addView(UI.text(this, "🔒", 48f))
        col.addView(UI.text(this, getString(R.string.choose_lang), 22f, Color.WHITE, true),
            UI.params(this, UI.WRAP, UI.WRAP, 12))
        col.addView(UI.button(this, "বাংলা") { setLang("bn") }, UI.params(this, UI.MATCH, UI.WRAP, 28))
        col.addView(UI.button(this, "English") { setLang("en") }, UI.params(this, UI.MATCH, UI.WRAP, 14))
        UI.show(root, col)
    }

    private fun setLang(l: String) {
        Prefs.lang = l
        step = 1
        render()
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(l))
    }

    private fun stepType() {
        val col = UI.column(this)
        col.addView(UI.text(this, getString(R.string.choose_type), 22f, Color.WHITE, true))
        col.addView(UI.button(this, getString(R.string.type_pin)) {
            type = "pin"
            step = 2
            render()
        }, UI.params(this, UI.MATCH, UI.WRAP, 28))
        col.addView(UI.button(this, getString(R.string.type_pattern)) {
            type = "pattern"
            step = 2
            render()
        }, UI.params(this, UI.MATCH, UI.WRAP, 14))
        UI.show(root, col)
    }

    private fun stepCred() {
        first = null
        val isPin = type == "pin"
        val createText = getString(if (isPin) R.string.create_pin else R.string.create_pattern)
        val col = UI.column(this)
        val title = UI.text(this, createText, 22f, Color.WHITE, true)
        col.addView(title)

        val handler: (String) -> Boolean = { v ->
            val f = first
            if (!isPin && v.length < 4) {
                Toast.makeText(this, R.string.pattern_short, Toast.LENGTH_SHORT).show()
                false
            } else if (f == null) {
                first = v
                title.text = getString(if (isPin) R.string.confirm_pin else R.string.confirm_pattern)
                true
            } else if (f == v) {
                Prefs.setCred(type, v)
                if (reset) {
                    finishFlow()
                } else {
                    step = 3
                    render()
                }
                true
            } else {
                first = null
                title.text = createText
                Toast.makeText(this, R.string.mismatch, Toast.LENGTH_SHORT).show()
                false
            }
        }

        if (isPin) {
            col.addView(PinPadView(this, handler), UI.params(this, UI.WRAP, UI.WRAP, 20))
        } else {
            val size = minOf(resources.displayMetrics.widthPixels - UI.dp(this, 64), UI.dp(this, 320))
            col.addView(PatternView(this, handler), UI.params(this, size, size, 20))
        }
        UI.show(root, col)
    }

    private fun stepQa() {
        val col = UI.column(this)
        col.addView(UI.text(this, getString(R.string.qa_title), 22f, Color.WHITE, true))
        val qs = resources.getStringArray(R.array.questions)
        val chips = ArrayList<TextView>()
        fun paint() {
            for (i in chips.indices) {
                chips[i].background = UI.round(this, if (i == qIdx) 0x5522D3EE else UI.CARD, 14)
            }
        }
        for (i in qs.indices) {
            val t = UI.text(this, qs[i], 15f)
            t.setPadding(UI.dp(this, 16), UI.dp(this, 12), UI.dp(this, 16), UI.dp(this, 12))
            t.setOnClickListener {
                qIdx = i
                paint()
            }
            chips.add(t)
            col.addView(t, UI.params(this, UI.MATCH, UI.WRAP, 8))
        }
        paint()
        val ans = UI.edit(this, getString(R.string.answer_hint))
        col.addView(ans, UI.params(this, UI.MATCH, UI.WRAP, 16))
        col.addView(UI.button(this, getString(R.string.next)) {
            val a = ans.text.toString()
            if (a.isBlank()) {
                Toast.makeText(this, R.string.answer_hint, Toast.LENGTH_SHORT).show()
            } else {
                code = Prefs.newCode()
                Prefs.setRecovery(qIdx, a, code)
                step = 4
                render()
            }
        }, UI.params(this, UI.MATCH, UI.WRAP, 16))
        UI.show(root, col)
    }

    private fun stepCode() {
        val col = UI.column(this)
        col.addView(UI.text(this, "🔑", 44f))
        col.addView(UI.text(this, getString(R.string.code_title), 22f, Color.WHITE, true),
            UI.params(this, UI.WRAP, UI.WRAP, 8))
        val c = UI.text(this, code, 28f, UI.ACCENT, true)
        c.typeface = Typeface.MONOSPACE
        c.setPadding(UI.dp(this, 16), UI.dp(this, 20), UI.dp(this, 16), UI.dp(this, 20))
        c.background = UI.round(this, UI.CARD, 16)
        c.setTextIsSelectable(true)
        col.addView(c, UI.params(this, UI.MATCH, UI.WRAP, 24))
        col.addView(UI.text(this, getString(R.string.code_note), 14f, 0xCCFFFFFF.toInt()),
            UI.params(this, UI.WRAP, UI.WRAP, 16))
        col.addView(UI.button(this, getString(R.string.done)) {
            Prefs.isSetup = true
            finishFlow()
        }, UI.params(this, UI.MATCH, UI.WRAP, 28))
        UI.show(root, col)
    }

    private fun finishFlow() {
        AppLockState.selfUnlocked = true
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(i)
        finish()
    }
}
