package com.myapplock.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import androidx.core.os.LocaleListCompat
import androidx.core.widget.doAfterTextChanged

private data class AppItem(val pkg: String, val label: String)

class MainActivity : AppCompatActivity() {
    private class Holder(val icon: ImageView, val name: TextView, val sw: SwitchCompat)

    private var all: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()
    private val icons = HashMap<String, Drawable?>()
    private lateinit var content: LinearLayout
    private lateinit var status: LinearLayout
    private lateinit var adapter: BaseAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.background = UI.gradient()
        content.setPadding(UI.dp(this, 20), UI.dp(this, 28), UI.dp(this, 20), UI.dp(this, 8))
        content.visibility = View.INVISIBLE
        setContentView(content)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val t1 = UI.text(this, getString(R.string.app_name), 26f, Color.WHITE, true)
        t1.gravity = Gravity.START
        val t2 = UI.text(this, getString(R.string.tagline), 13f, 0xAAFFFFFF.toInt())
        t2.gravity = Gravity.START
        titles.addView(t1)
        titles.addView(t2)
        head.addView(titles, LinearLayout.LayoutParams(0, UI.WRAP, 1f))
        head.addView(UI.ghost(this, "🌐") { toggleLang() })
        head.addView(UI.ghost(this, "🔑") {
            startActivity(Intent(this, SetupActivity::class.java).putExtra("reset", true))
        })
        content.addView(head)

        status = LinearLayout(this)
        status.orientation = LinearLayout.VERTICAL
        status.setPadding(UI.dp(this, 16), UI.dp(this, 14), UI.dp(this, 16), UI.dp(this, 14))
        content.addView(status, UI.params(this, UI.MATCH, UI.WRAP, 16))

        val search = UI.edit(this, getString(R.string.search_hint))
        content.addView(search, UI.params(this, UI.MATCH, UI.WRAP, 12))
        search.doAfterTextChanged { applyFilter(it?.toString() ?: "") }

        val list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.setBackgroundColor(Color.TRANSPARENT)
        adapter = object : BaseAdapter() {
            override fun getCount(): Int = shown.size
            override fun getItem(p: Int): Any = shown[p]
            override fun getItemId(p: Int): Long = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val row = cv ?: makeRow()
                bind(row, shown[p])
                return row
            }
        }
        list.adapter = adapter
        content.addView(list, UI.params(this, UI.MATCH, 0, 8).also { it.weight = 1f })

        loadApps()
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val items = pm.queryIntentActivities(i, 0)
                .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                .filter { it.pkg != packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                all = items
                applyFilter("")
            }
        }.start()
    }

    private fun applyFilter(q: String) {
        shown = all.filter { it.label.contains(q, true) }
        adapter.notifyDataSetChanged()
    }

    private fun makeRow(): View {
        val outer = LinearLayout(this)
        outer.setPadding(0, UI.dp(this, 4), 0, UI.dp(this, 4))
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = UI.round(this, UI.CARD, 16)
        card.setPadding(UI.dp(this, 14), UI.dp(this, 10), UI.dp(this, 14), UI.dp(this, 10))
        val icon = ImageView(this)
        val name = UI.text(this, "", 16f)
        name.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        val sw = SwitchCompat(this)
        card.addView(icon, LinearLayout.LayoutParams(UI.dp(this, 44), UI.dp(this, 44)))
        val lp = LinearLayout.LayoutParams(0, UI.WRAP, 1f)
        lp.marginStart = UI.dp(this, 14)
        card.addView(name, lp)
        card.addView(sw)
        card.setOnClickListener { sw.toggle() }
        outer.addView(card, LinearLayout.LayoutParams(UI.MATCH, UI.WRAP))
        outer.tag = Holder(icon, name, sw)
        return outer
    }

    private fun bind(row: View, item: AppItem) {
        val h = row.tag as Holder
        h.name.text = item.label
        h.icon.setImageDrawable(icons.getOrPut(item.pkg) {
            try {
                packageManager.getApplicationIcon(item.pkg)
            } catch (e: Exception) {
                null
            }
        })
        h.sw.setOnCheckedChangeListener(null)
        h.sw.isChecked = Prefs.lockedApps.contains(item.pkg)
        h.sw.setOnCheckedChangeListener { _, on ->
            val s = Prefs.lockedApps.toMutableSet()
            if (on) s.add(item.pkg) else s.remove(item.pkg)
            Prefs.lockedApps = s
            updateStatus()
        }
    }

    private fun a11yEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains("$packageName/") && s.contains("AppLockService")
    }

    private fun updateStatus() {
        status.removeAllViews()
        if (a11yEnabled()) {
            status.background = UI.round(this, 0x3322C55E, 16)
            val t = UI.text(this, "✅  " + getString(R.string.active) + " · " +
                getString(R.string.apps_locked, Prefs.lockedApps.size), 15f, Color.WHITE, true)
            status.addView(t)
        } else {
            status.background = UI.round(this, 0x44F87171, 16)
            status.addView(UI.text(this, "⚠️  " + getString(R.string.perm_title), 16f, Color.WHITE, true))
            status.addView(UI.text(this, getString(R.string.perm_text), 14f, 0xDDFFFFFF.toInt()),
                UI.params(this, UI.WRAP, UI.WRAP, 6))
            status.addView(UI.button(this, getString(R.string.enable)) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }, UI.params(this, UI.MATCH, UI.WRAP, 12))
        }
    }

    private fun toggleLang() {
        val next = if (Prefs.lang == "bn") "en" else "bn"
        Prefs.lang = next
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(next))
    }

    override fun onResume() {
        super.onResume()
        if (!Prefs.isSetup) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }
        if (AppLockState.selfUnlocked && AppLockState.leftAt > 0 &&
            SystemClock.elapsedRealtime() - AppLockState.leftAt > 30_000
        ) {
            AppLockState.selfUnlocked = false
        }
        if (!AppLockState.selfUnlocked) {
            content.visibility = View.INVISIBLE
            startActivity(Intent(this, LockActivity::class.java))
            return
        }
        content.visibility = View.VISIBLE
        updateStatus()
    }

    override fun onStop() {
        super.onStop()
        AppLockState.leftAt = SystemClock.elapsedRealtime()
    }
}
