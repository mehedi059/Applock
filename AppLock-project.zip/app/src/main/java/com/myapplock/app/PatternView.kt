package com.myapplock.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/** onDone returns true if accepted; false flashes the pattern red. */
class PatternView(c: Context, private val onDone: (String) -> Boolean) : View(c) {
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sel = ArrayList<Int>()
    private var fx = 0f
    private var fy = 0f
    private var drawing = false
    private var err = false

    init {
        linP.strokeWidth = UI.dp(c, 5).toFloat()
        linP.strokeCap = Paint.Cap.ROUND
        linP.style = Paint.Style.STROKE
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = MeasureSpec.getSize(w)
        setMeasuredDimension(s, s)
    }

    private fun px(i: Int): Float = width * (1 + (i % 3) * 2) / 6f
    private fun py(i: Int): Float = height * (1 + (i / 3) * 2) / 6f

    override fun onDraw(canvas: Canvas) {
        val col = if (err) 0xFFFF6B6B.toInt() else UI.ACCENT
        linP.color = col
        for (k in 1 until sel.size) {
            canvas.drawLine(px(sel[k - 1]), py(sel[k - 1]), px(sel[k]), py(sel[k]), linP)
        }
        if (drawing && sel.isNotEmpty()) {
            canvas.drawLine(px(sel.last()), py(sel.last()), fx, fy, linP)
        }
        for (i in 0 until 9) {
            val on = sel.contains(i)
            if (on) {
                dotP.color = col
                dotP.alpha = 60
                canvas.drawCircle(px(i), py(i), UI.dp(context, 26).toFloat(), dotP)
            }
            dotP.color = if (on) col else 0x88FFFFFF.toInt()
            canvas.drawCircle(px(i), py(i), UI.dp(context, if (on) 11 else 7).toFloat(), dotP)
        }
    }

    private fun hit(x: Float, y: Float) {
        val r = width / 9f
        for (i in 0 until 9) {
            if (!sel.contains(i) && abs(px(i) - x) < r && abs(py(i) - y) < r) {
                sel.add(i)
                performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                break
            }
        }
    }

    fun reset(error: Boolean) {
        err = error
        invalidate()
        postDelayed({
            sel.clear()
            err = false
            invalidate()
        }, if (error) 600L else 250L)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                sel.clear()
                err = false
                drawing = true
                fx = e.x
                fy = e.y
                hit(e.x, e.y)
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                fx = e.x
                fy = e.y
                hit(e.x, e.y)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                drawing = false
                if (e.action == MotionEvent.ACTION_UP && sel.isNotEmpty()) {
                    val ok = onDone(sel.joinToString(""))
                    reset(!ok)
                } else {
                    sel.clear()
                }
            }
        }
        invalidate()
        return true
    }
}
