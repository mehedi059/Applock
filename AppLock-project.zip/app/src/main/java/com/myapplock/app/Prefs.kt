package com.myapplock.app

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

object AppLockState {
    @Volatile var unlocked: String? = null
    @Volatile var selfUnlocked = false
    @Volatile var leftAt = 0L
}

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("lock", Context.MODE_PRIVATE)
        }
    }

    var isSetup: Boolean
        get() = sp.getBoolean("setup", false)
        set(v) { sp.edit().putBoolean("setup", v).apply() }

    var type: String
        get() = sp.getString("type", "pin") ?: "pin"
        set(v) { sp.edit().putString("type", v).apply() }

    var lang: String
        get() = sp.getString("lang", "") ?: ""
        set(v) { sp.edit().putString("lang", v).apply() }

    var lockedApps: Set<String>
        get() = HashSet(sp.getStringSet("apps", emptySet()) ?: emptySet())
        set(v) { sp.edit().putStringSet("apps", HashSet(v)).apply() }

    val qIdx: Int
        get() = sp.getInt("q", 0)

    private fun hash(s: String): String {
        val salt = sp.getString("salt", null) ?: UUID.randomUUID().toString().also {
            sp.edit().putString("salt", it).apply()
        }
        val d = MessageDigest.getInstance("SHA-256").digest((salt + s).toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }

    private fun normCode(c: String) = c.uppercase().filter { it.isLetterOrDigit() }
    private fun normAns(a: String) = a.trim().lowercase()

    fun setCred(t: String, v: String) {
        sp.edit().putString("type", t).putString("cred", hash(v)).apply()
    }

    fun checkCred(v: String) = hash(v) == sp.getString("cred", "")

    fun setRecovery(q: Int, answer: String, code: String) {
        sp.edit().putInt("q", q)
            .putString("ans", hash(normAns(answer)))
            .putString("code", hash(normCode(code)))
            .apply()
    }

    fun checkAnswer(a: String) = hash(normAns(a)) == sp.getString("ans", "")
    fun checkCode(c: String) = hash(normCode(c)) == sp.getString("code", "")

    fun newCode(): String {
        val a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = SecureRandom()
        return (0 until 12).map { a[r.nextInt(a.length)] }
            .chunked(4)
            .joinToString("-") { it.joinToString("") }
    }
}
