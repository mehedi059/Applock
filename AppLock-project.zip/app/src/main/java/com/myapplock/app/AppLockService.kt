package com.myapplock.app

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

class AppLockService : AccessibilityService() {
    private var imePkgs: Set<String> = emptySet()
    private var lastPkg = ""
    private var lastAt = 0L

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            AppLockState.unlocked = null
            AppLockState.selfUnlocked = false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Prefs.init(this)
        val f = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenOff, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenOff, f)
        }
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imePkgs = imm.enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Exception) {
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || imePkgs.contains(pkg)) return
        if (!Prefs.lockedApps.contains(pkg)) {
            AppLockState.unlocked = null
            return
        }
        if (AppLockState.unlocked == pkg) return
        val now = SystemClock.elapsedRealtime()
        if (pkg == lastPkg && now - lastAt < 700) return
        lastPkg = pkg
        lastAt = now
        val i = Intent(this, LockActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        i.putExtra("pkg", pkg)
        startActivity(i)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        try {
            unregisterReceiver(screenOff)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
