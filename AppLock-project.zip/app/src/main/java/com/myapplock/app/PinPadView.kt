package com.myapplock.app

import android.content.Context
import android.graphics.Color
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** onSubmit returns true if the entry was accepted. The pad clears itself after every submit. */
class PinPadView(c: Context, private val onSubmit: (String) -> Boolean) : LinearLayout(c) {
    private val sb = StringBuilder()
    private val dots = TextView(c)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        dots.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        dots.setTextColor(UI.ACCENT)
        dots.gravity = Gravity.CENTER
        addView(dots, LayoutParams(LayoutParams.MATCH_PARENT, UI.dp(c, 56)))
        refresh()
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "✓")
        for (r in 0 until 4) {
            val row = LinearLayout(c)
            row.gravity = Gravity.CENTER
            for (k in 0 until 3) row.addView(key(keys[r * 3 + k]))
            addView(row)
        }
    }

    private fun refresh() {
        dots.text = if (sb.isEmpty()) "○ ○ ○ ○" else "● ".repeat(sb.length).trim()
    }

    private fun key(label: String): View {
        val c = context
        val t = UI.text(c, label, 26f, Color.WHITE, true)
        t.background = UI.round(c, UI.CARD, 36)
        val size = UI.dp(c, 72)
        val p = LayoutParams(size, size)
        p.setMargins(UI.dp(c, 10), UI.dp(c, 8), UI.dp(c, 10), UI.dp(c, 8))
        t.layoutParams = p
        t.setOnClickListener {
            when (label) {
                "⌫" -> {
                    if (sb.isNotEmpty()) sb.deleteCharAt(sb.length - 1)
                }
                "✓" -> {
                    if (sb.length >= 4) {
                        val v = sb.toString()
                        sb.clear()
                        onSubmit(v)
                    }
                }
                else -> {
                    if (sb.length < 8) sb.append(label)
                }
            }
            refresh()
        }
        return t
    }
}
